/*
 ==============================================================================
 Regular Expression Examples
 ==============================================================================
*/

#include <iostream>
#include <string>
#include <regex>
#include <chrono>

int main() {
	std::cout.setf(std::ios::boolalpha);
	// std::regex re{R"(-?\d+)"};
	// std::regex re{R"(\d*[.]\d+|\d+[.]\d*)"};

	// some basic components to construct the duration regular expression
	const std::string hours     {R"((\d\d?))"}; // one or two digits
	const std::string minutes   {R"((\d\d))" }; // exactly two digits
	const std::string seconds   {R"((\d\d))" }; // exactly two digits
	const std::string opt_ws    {R"(\s*)"    }; // optional white space
	const std::string plus_minus{R"(([+-]))" }; // a plus or a minus sign

	// intermediate level regular expressions (to compose finally)
	const std::string duration{
		       hours + ':' + minutes            // mandatory hours and minutes
	         + "(?:" + ':' + seconds + ")?"};   // followed by optional seconds

	// finally regular expression actually (to be analyzed)
	std::regex re{opt_ws + duration             // a first duration
		        + opt_ws + plus_minus           // plus or minus
	            + opt_ws + duration             // a second duration
	            + opt_ws};

	std::string line;
	while (std::getline(std::cin, line) && line != "q") {
		std::smatch m;
		const auto ok = std::regex_match(line, m, re);
		std::cout << "ok=" << ok
				  << " m.position()=" << m.position()
				  << " m.length()=" << m.length()
				  << " m[0]=" << m[0]
 				  << " m[1]=" << m[1]
				  << " m[2]=" << m[2]
 				  << " m[3]=" << m[3]
				  << " m[4]=" << m[4]
 				  << " m[5]=" << m[5]
				  << " m[6]=" << m[6]
				  << " m[7]=" << m[7]
				  << std::endl;
		if (!ok) continue;

		using std::chrono::hours;
		using std::chrono::minutes;
		using std::chrono::seconds;

		const minutes x{3};
		const hours y{x.count()};
		const hours hr1{std::stoi(m[1])};
		const minutes mn1{std::stoi(m[2])};
		const seconds sc1{m[3].str().empty() ? 0 : std::stoi(m[3])};
		const auto op = m[4];
   		const hours hr2{std::stoi(m[5])};
   		const minutes mn2{std::stoi(m[6])};
   		const seconds sc2{m[7].str().empty() ? 0 : std::stoi(m[7])};
		const auto d1 = hr1 + mn1 + sc1;
		const auto d2 = hr2 + mn2 + sc2;
		const auto total_seconds = (op == "+") ? (d1 + d2) : (d1 - d2);
		std::cout << "total seconds=" << total_seconds.count() << std::endl;
	}
}

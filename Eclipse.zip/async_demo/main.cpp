/*
 ==============================================================================
 What output may the following program generate?
 ==============================================================================
*/

#include <atomic>
#include <iostream>
#include <thread>
#include <future>
#include <chrono>

std::atomic_int counter{0};

void uptick(int n) {
	while (n-- > 0) {
	    int local = counter;
	    counter = ++local;
	}
}

int main() {
	auto f1 = std::async(std::launch::async, []() {uptick(5);});
	auto f2 = std::async(std::launch::async, []() {uptick(3);});
	f1.get();
	f2.get();
	std::cout << "final counter = " << counter << std::endl;
	//
	// What possibilities exist for the final value of counter?
	// at least: [ ] = 1, [ ] = 2, [ ] = 3, [ ] = 5, [ ] = 8
	// at most : [ ] = 2, [ ] = 3, [ ] = 5, [ ] = 8, [ ] = 10
}

// scroll down for the solution
















































 /* Minimum is 2 and Maximum is 8
  * Explanation for Maximum is simple: there are at increment operations, if non invalidates the
  * previous (because threads happen to be executed sequentilly) the value 8 is the maximum that
  * can be achieved.
  * Explanation for Minimum is more complicated: the first thread starting runs to the point AFTER
  * it reading `counter` for the first time, then gets suspended. Then the SECOND thread runs near
  * to completion and gets suspended just BEFORE its LAST reading of `counter`. At that point the
  * first thread does a SINGLE write, effectively (re-) setting `counter` to `1` and gets again
  * suspended, while the second thread does its LAST reading of `counter` and picks the `1`, left
  * there by the first thread. Before the second thread can continue the first runs to its end,
  * and finally the second does its (last) write of `counter` with the `1` incremented to `2`.
  *
  * It may be easier to see with an unrolled loop:
  *
		void uptick(int n) {
 			int local = counter; <---(1) 1st thread started suspends AFTER reading `counter`
			counter = ++local;   <---(3) 1st thread writes `1` to `counter` and suspends again
			while (n-- > 2) { // (see note below)
				int local = counter;
				counter = ++local;
			} <----------------------(2) 2nd thread stared suspends on leaving the loop
			int local = counter; <---(4) 2nd thread reads `1` and suspends
			counter = ++local; <-----(6) 2nd thread writes `2` and completes
		} <--------------------------(5) 1st thread completes
  * For the timing of the sequence of events, leading to a final value `2`, read the numbers with
  * which left of the textual description in ascending order.
  * Note also that comparing decremented `n` to `2` (instead of `0`, like in the original version)
  * is an adjustment made to compensate. But be sure to understand that the minimal result will
  * always be `2`, no matter how large `n` is. So the adjustment in unimportant* to the explanation
  * given here. (Only, if the loop body is executed very often, the probability to get the final
  * result `2` will decrease drastically.)
 */

/*
 ==============================================================================
 Variant Examples
 ==============================================================================
 AUFGABEN:

 1. Lesen Sie sich den (langen) Kommentar bei der Funktion `do_not_enable_this`
    durch, der erklärt, warum die Zuweisung von `nullptr´ ursprünglich zu einem
    LAUFZEIT-Absturz geführt hat.
    (Es ist wichtig, dass Sie verstehen, dass das Problem NICHT DIREKT mit der
    `boost::variant` zu tun hatte sondern ein INDIREKTER Effekt der Tatsache
    war, dass die `std::string`-Klasse einen Konstruktor für char-Zeiger hat
    und den übergebenen Zeiger dann zur Laufzeit auf Gültigkeit überprüft.)
    Untersuchen Sie anschließend, wie das ursprüngliche Problem in der Ihnen
    nun vorliegenden Version behoben wurde.

 2. Bestätigen Sie sich (durch einen Vergleich der Ausgaben), dass momentanen
    die Funktion `print_variant_element` und der `print_data`-Visitor exakt
    das selbe tun (auf unterschiedliche Weise).

 3. Fügen Sie der `boost::variant` ein weiteres Element vom Typ `int` hinzu.
    (a) Was passiert, wenn Sie vergessen, diese zusätzliche Möglichkeit im
    `print_data`-Visitor einzubauen?
    (b) Was passiert, wenn Sie vergessen, diese zusätzliche Möglichkeit in der
    Funktion `print_variant_element` einzubauen?

 4. Wie kann man den gleichartigen QUELLTEXT in der Implementierung einiger
    Funktionen des `print_data`-Visitors durch eine Template ersetzen?

 5. Gibt es eine solche Möglichkeit, gleichartigen Code nur EINMALIG schreiben
    zu müssen auch für die `print_variant_element`-Funktion?

 6. Was passiert nun - wenn im `print_data`-Visitor gleichartiger Code durch
    eine Template abgedeckt ist - wenn man zu der der Variant einen weiteren
    Datentyp hinzufügt aber vergisst, diesen auch der Visitor-Implementierung
    hinzuzufügen?
*/

#include <iostream>
#include <string>
#include <boost/variant.hpp>

void do_not_enable_this() {
    // the fact that the program crashes when a `nullptr` is assigned to the boost::variant
	// has nothing to do with the class (variant) but is due to an unlucky chain of facts:
	// 1. std::string has a constructor for `const char *` to support classic literal strings
	//    in double quotes and turn them into proper instances of the `std::string` class.
	// 2. C++11 `nullptr` actually has the type `std::nullptr_t` which is compatible to ANY
	//    pointer type
	// 3. To safe-guard against invalid content the CONSTRUCTOR of `std::string` does a test
	//    at RUNTIME, throwing an exception if the (expected) `const char *` - into which
	//    `nullptr` was converted - is not a valid address (which it of course isn't.)
	// 4. Because (1, 2, 3) when `nullptr` is assigned to an `boost::variant` which has
	//    `std::string` as one its types, the `std::string` gets selected for the `nullptr`
	//    assignment ... and then crashes BEFORE the visitor is even reached.
	//
	// NOTE AGAIN: The problem is NOT the `boost::variant` but the fact an `std::string`
	//             ACCEPTS a `nullptr` at compile-time as constructor argument but then
	//             CRASHES at runtime, as demonstrated by the following code.
	std::cout << "let's go ..." << std::flush;
	std::string nonsense{nullptr}; // <--- will crash already here!
	std::cout << " DONE" << std::endl;
}

#if 1
typedef boost::variant<bool,
		               std::nullptr_t,
                       std::string,
                       double> MyVariant;
#else
// For unknown reasons Eclipse flags the new C++11 `using` type alias syntax
// as error, but the program compiles without any problems. So, if you feel
// not distracted by the problem marker, you may also enable it.
using MyVariant = boost::variant<bool,
		               std::nullptr_t,
                       std::string,
                       double>;
#endif

void print_variant_element(const MyVariant& v) {
	if (auto* p = boost::get<bool          >(&v)) std::cout << *p;
	if (auto* p = boost::get<double        >(&v)) std::cout << *p;
	if (          boost::get<std::nullptr_t>(&v)) std::cout << "nullptr";
	if (auto* p = boost::get<std::string   >(&v)) std::cout << '"' << *p << '"';
}

struct print_data : boost::static_visitor<> {
#if 0
    void operator()(bool b) const { std::cout << b; }
    void operator()(double d) const { std::cout << d; }
#else
    template<typename T>
    void operator()(const T& d) const { std::cout << d; }
#endif
    void operator()(std::nullptr_t) const { std::cout << "nullptr"; }
    void operator()(const std::string &s) const {
    	std::cout << '"' << s << '"';
    }
};

class to_string : boost::static_visitor<> {
	std::string &result;
public:
	to_string(std::string &r) : result(r) {}
    void operator()(bool b) const { result = b ? "true" : "false"; }
    void operator()(double d) const { result = std::to_string(d); }
    void operator()(std::nullptr_t) const { result = "nullptr"; }
    void operator()(const std::string &s) const { result = '"' + s + '"'; }
};

int main() {
	//do_not_enable_this(); // at least not before reading the long comment above!!!

	std::cout.setf(std::ios::boolalpha);
	MyVariant x;
	x = std::sqrt(2.0);         // can be set to any other type from
	                            // the list, either exactly matching
	x = std::string("hello");   // but also applying conversions, if
	                            // an unambiguous choice can be made,
	x = "world";                // like const char * to std::string
    x = nullptr;                // would be used to initialise the
	                            // std::string and then crash at
	                            // run-time (see explanation in
	                          // implementation of `do_not_enable_this()`
    std::string result;
    boost::apply_visitor(to_string{result}, x);
    std::cout << result << std::endl;
//	boost::apply_visitor(print_data{}, x); std::cout << std::endl;
//	print_variant_element(x);              std::cout << std::endl;
}

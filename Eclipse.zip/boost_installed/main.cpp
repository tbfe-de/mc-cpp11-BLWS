#include <boost/version.hpp>

#include <iostream>
#include <boost/regex.hpp>

int main() {
	std::cout.setf(std::ios::boolalpha);
	std::cout << BOOST_VERSION << std::endl;
	std::cout << boost::regex_match("aaa", boost::regex("a+")) << std::endl;
}

#include <iostream>
#include <iterator>
#include <string>

#include <boost/bimap.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/range/irange.hpp>

int main() {

	using int_str_mapping = boost::bimap<int, std::string>;
	int_str_mapping mis;
	mis.insert({1, "Monday"});
	mis.insert({2, "Tuesday"});
	mis.insert({3, "Wednesday"});
	mis.insert({4, "Thursday"});
	mis.insert({5, "Friday"});
	mis.insert({6, "Saturday"});
	mis.insert({7, "Sunday"});

	for (auto& e : mis.left)
		std::cout << e.first << " --> " << e.second << std::endl;
	for (auto& e : mis.right)
		std::cout << e.first << " --> " << e.second << std::endl;

	boost::copy(mis.right | boost::adaptors::map_keys,
 			    std::ostream_iterator<std::string>{std::cout, " "});
	std::cout << std::endl;

}

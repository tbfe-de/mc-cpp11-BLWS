/*
 ==============================================================================
 Try `std::vector<const int>` (as suggested by C.A.)
 ==============================================================================
*/

#include <boost/lambda/lambda.hpp>
#include <boost/bind.hpp>
#include <algorithm>
#include <functional>
#include <iostream>
#include <vector>


bool less(int arg1, int arg2) { return (arg1 < arg2); }

int main() {
	std::vector<int> v = { 45, 12, 13, 20, -1, 8 };
	for (auto e : v) { std::cout << e << ' '; } std::cout << std::endl;
//	std::sort(v.begin(), v.end(), less);
//	std::sort(v.begin(), v.end(), [](int arg1, int arg2) {return (arg2 < arg1);});
//	{ using namespace std::placeholders;
//	  std::sort(v.begin(), v.end(), std::bind(less, _2, _1));
//	}
	{
	  std::sort(v.begin(), v.end(), boost::bind(less, _2, _1));
	}
	for (auto e : v) { std::cout << e << ' '; } std::cout << std::endl;
}


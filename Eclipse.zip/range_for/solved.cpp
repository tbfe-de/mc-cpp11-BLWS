/*
 ==============================================================================
 Demonstrate Range-Based Loops with `auto`-loop variables
 ==============================================================================
 Demonstrate range-based loops defining their loop variables
 - per value
 - per non-`const` reference
 - per `const` reference
*/

#define PART 1

#if PART == 1

// demonstrate "per value" loop variable
//
namespace my {
	class Copyable {
	public:
		Copyable (int v) : value{v} {}
		int value;
	};
}

#include <iostream>
#include <vector>

int main() {
	std::vector<my::Copyable> all = { my::Copyable{1}, my::Copyable{2} };
	for (auto e : all)
		std::cout << e.value << std::endl;
}

#elif PART == 2

// demonstrate "non-`const` reference" loop variable
//

namespace my {
	class Moveable {
	public:
		Moveable(const Moveable&) = delete;
		Moveable(Moveable&&) = default;
		Moveable (int v) : value{v} {}
		int value;
	};
}

#include <iostream>
#include <vector>

int main() {
	std::vector<my::Moveable> all;
	all.emplace_back(1);
	all.emplace_back(2);
	for (auto& e : all) {
		e.value *= 2;
		std::cout << e.value << std::endl;
	}
}

#elif PART == 3

// demonstrate "`const` reference" loop variable
//

namespace my {
	class Moveable {
	public:
		Moveable(const Moveable&) = delete;
		Moveable(Moveable&&) = default;
		Moveable (int v) : value{v} {}
		int value;
	};
}

#include <iostream>
#include <vector>

int main() {
	std::vector<my::Moveable> all;
	all.emplace_back(1);
	all.emplace_back(2);
//	auto const& all_const = all;
	for (/*const*/ auto& e : all) {
		if ((e.value = 0) || (e.value == 1)) // should be: if ((e == 0) ...
			continue;
		std::cout << e.value << std::endl;
	}
}

#endif

/*
 ==============================================================================
 Regular Xpressive Examples
 ==============================================================================
*/

#include <iostream>
#include <string>
#include <boost/xpressive/xpressive.hpp>

int main() {
	std::cout.setf(std::ios::boolalpha);

	namespace bx = boost::xpressive;

	bx::sregex re =                             // ----------------- captured as:
		*bx::space                              // zero or more white-space
	 >> (bx::s1= bx::repeat<1, 2>(bx::digit))   // one or two digits          [1]
     >>  ':'                                    // a colon
	 >> (bx::s2= bx::repeat<2, 2>(bx::digit))   // exactly two digits         [2]
	 >> !(                                      // optionally (start grouped)
	       ':'                                     // a colon
	    >> (bx::s3= bx::repeat<2, 2>(bx::digit))   // exactly two digits      [3]
	    )                                       // (end grouped)
	 >> *bx::space                              // zero or more white-space
	 >> (bx::s4= (bx::set= '+','-'))            // a plus or a minus          [4]
	 >> *bx::space                              // zero or more white-space
	 >> (bx::s5= bx::repeat<1, 2>(bx::digit))   // one or two digits          [5]
     >>  ':'                                    // a colon
	 >> (bx::s6= bx::repeat<2, 2>(bx::digit))   // exactly two digits         [6]
	 >> !(                                      // optionally (start grouped)
	       ':'                                     // a colon
	    >> (bx::s7= bx::repeat<2, 2>(bx::digit))   // exactly two digits      [7]
	    )                                       // (end grouped)
	 >> *bx::space                              // zero or more white-space
        ;
    std::string line;
	while (std::getline(std::cin, line) && line != "q") {
		bx::smatch m;
		const auto ok= bx::regex_match(line, m, re);
		std::cout << "ok=" << ok
				  << " m[1]=" << m[1]
 				  << " m[2]=" << m[2]
				  << " m[3]=" << m[3]
				  << " m[4]=" << m[4]
 				  << " m[5]=" << m[5]
				  << " m[6]=" << m[6]
				  << " m[7]=" << m[7]
				  << std::endl;
		if (!ok) continue;

		const auto hr1 = std::stoi(m[1]);
		const auto mn1 = std::stoi(m[2]);
		const auto sc1 = m[3].str().empty() ? 0 : std::stoi(m[3]);
		const auto op = m[4];
   		const auto hr2 = std::stoi(m[5]);
   		const auto mn2 = std::stoi(m[6]);
   		const auto sc2 = m[7].str().empty() ? 0 : std::stoi(m[7]);
		const auto d1 = 60*(60*hr1 + mn1) + sc1;
		const auto d2 = 60*(60*hr2 + mn2) + sc2;
		const auto total_seconds = (op == "+") ? (d1 + d2) : (d1 - d2);
		std::cout << "total seconds=" << total_seconds << std::endl;
	}
}

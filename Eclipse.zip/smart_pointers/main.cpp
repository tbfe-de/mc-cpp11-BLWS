/*
 ==============================================================================
 Demonstrate Smart-Pointers
 ==============================================================================
 */

#include <iostream>

#define PX(v)\
	(void)(std::cout << __FUNCTION__ << ":" << __LINE__ << "\t"\
	                 << #v << " --> " << (v) << std::endl)

class X {
public:
	X()         { std::cout << "X @" << (void*)this << " default-constructed\n"; }
	X(const X&) { std::cout << "X @" << (void*)this << " copy-constructed\n"; }
	X(X&&)      { std::cout << "X @" << (void*)this << " move-constructed\n"; }
	~X()        { std::cout << "X @" << (void*)this << " destroyed\n"; }
};

#define PART 1

#if PART == 1

// demonstrate std::shared_ptr
//
int main() {
	X obj{};
}

#elif PART == 2

// demonstrate std::unique_ptr
//

#elif PART == 3

// demonstrate boost::intrusive_ptr
//

#elif PART == 4

// demonstrate boost::ptr_vector
//

#endif

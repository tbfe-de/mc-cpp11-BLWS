#include <iostream>
#include <random>

#if 0
int throw_dice() { return 1 + std::rand() % 6; }
#else
int throw_dice() {
    static std::random_device rd;
    static std::mt19937 gen{rd()};
    static std::uniform_int_distribution<> dis(1, 6);
    return dis(gen);
    //return (gen() >> 27) & 1;
}
#endif

int main() {
	for (int i = 0; i < 4
	0; ++i)
	    std::cout << throw_dice() << ' ';
    std::cout << std::endl;

}

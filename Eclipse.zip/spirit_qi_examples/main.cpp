/*
 ==============================================================================
 Spirit-Parser (Qi) Examples
 ==============================================================================
*/

#include <iostream>
#include <sstream>
#include <string>
#include <boost/spirit/home/qi.hpp>

bool parse_duration_expression(std::string s, int& result) {

	namespace bsq = boost::spirit::qi;
	using rule = bsq::rule<std::string::iterator>;

	rule digit_1_2
		= bsq::uint_parser<unsigned, 10, 1, 2>{};
	rule digit_2_2
		= bsq::uint_parser<unsigned, 10, 2, 2>{};
	rule multiplier
		= bsq::int_;
	rule colon
		= bsq::char_(':');
	rule duration
		= bsq::lexeme[
		     digit_1_2
		  >> colon >> digit_2_2
		  >> -(colon >> digit_2_2)
		];
	rule add_sub = bsq::char_('+') | bsq::char_('-');
	rule mul_div = bsq::char_('*') | bsq::char_('/');
	rule multiplied_duration;
	rule duration_sequence
		= multiplied_duration >> *(add_sub >> multiplied_duration)
		;
	multiplied_duration
		= duration
		| bsq::char_('(') >> duration_sequence >> bsq::char_(')')
		| duration >> *(mul_div >> multiplier)
		;
	auto beg = s.begin();
	auto end = s.end();
	auto ok = bsq::phrase_parse(
		beg, end, duration_sequence, bsq::space
	);
	result = -1;
	return ok && (beg == end);
}

int main() {
	std::cout.setf(std::ios::boolalpha);

    std::string line;
	while (std::getline(std::cin, line) && line != "q") {
		int total_seconds;
		if (!parse_duration_expression(line, total_seconds)) continue;
		std::cout << "total seconds=" << total_seconds << std::endl;
	}
}

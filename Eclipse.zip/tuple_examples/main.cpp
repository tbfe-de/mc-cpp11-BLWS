/*
 ==============================================================================
 Tuple Examples
 ==============================================================================
*/

#include <iostream>
#include <tuple>

#if 0
std::tuple<bool, double> foo() {
	// ... whatever
//	return std::tuple<bool, double>{true, 12.34};
}
#else
auto foo() {
	// ... whatever
 	return std::make_tuple(true, 12.34);
}
#endif

int main() {
	std::cout.setf(std::ios::boolalpha);
	bool b;
	double d;
	std::tie(b, d) = foo();
	std::cout << "b = " << b << std::endl;
	std::cout << "d = " << d << std::endl;
}

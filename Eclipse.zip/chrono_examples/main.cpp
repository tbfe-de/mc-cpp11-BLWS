/*
 ==============================================================================
 Demonstrate Chrono Library
 ==============================================================================
*/
#include <chrono>
#include <iostream>
#include <string>

namespace sc = std::chrono;

std::string to_string(sc::seconds sec) {
    const auto h = sc::duration_cast<sc::hours>(sec);
    const auto m = sc::duration_cast<sc::minutes>(sec-h);
    const auto s = sc::duration_cast<sc::seconds>(sec-h-m);
    return std::to_string(h.count()) + "h"
         + std::to_string(m.count()) + "m"
         + std::to_string(s.count()) + "s";
}

template<typename Clock>
void show_clock() {
        using period = typename Clock::period;
        using limits = std::numeric_limits<typename Clock::rep>;
        std::cout << "resolution : " << period::num << '/' << period::den << '\n';
        std::cout << "value range: " << limits::min() << " .. " << limits::max() << '\n';
        const auto tse = Clock::now().time_since_epoch();
        const auto sse = sc::duration_cast<sc::seconds>(tse).count();
        std::cout << "since epoch: " << sse /60/60/24/365 << "+ years\n";
        std::cout << "         or: " << sse /60/60/24 << "+ days\n";
        std::cout << "         or: " << sse /60/60 << "+ hours\n";
        std::cout << "         or: " << sse /60 << "+ minutes\n";
        std::cout << "         or: " << sse << "+ seconds\n";
        std::cout << "or in ticks: " << tse.count() << '\n';
}

int main() {
	std::chrono::minutes m{3};
	std::cout << m.count() << std::endl;
	std::chrono::seconds s{m};
	std::cout << s.count() << std::endl;
	s += std::chrono::seconds{70};
	std::cout << s.count() << std::endl;
	m = std::chrono::duration_cast<std::chrono::hours>(s);
	std::cout << m.count() << std::endl;
	s = std::chrono::seconds{-61};
	m = std::chrono::duration_cast<std::chrono::minutes>(s);
	std::cout << m.count() << std::endl;
	std::cout << to_string(std::chrono::seconds{-3601}) << std::endl;
	show_clock<std::chrono::high_resolution_clock>();

	using float_seconds = std::chrono::duration<float>;
	float_seconds fs = std::chrono::microseconds{680};
	std::cout << fs.count() << std::endl;

	using float_milliseconds = std::chrono::duration<float, std::ratio<1,1000>>;
	float_milliseconds fms = std::chrono::microseconds{680};
	std::cout << fms.count() << std::endl;
}

/*
 ==============================================================================
 Regular Expression Examples
 ==============================================================================
*/

#include <iostream>
#include <string>
#include <boost/tokenizer.hpp>

#define PART 4

#if PART == 1
// adapted from Boost.Tokenizer, simple_example_1.cpp

int main() {
	std::string input{"This\n\tis, a   test"};
    // all defaults, tokens separated by sequences of white space
    boost::tokenizer<> tok{input};
    for (auto beg = tok.begin(); beg != tok.end(); ++beg){
        std::cout << *beg << std::endl;
    }
}

#elif PART == 2
// adapted from Boost.Tokenizer, char_sep_example_1.cpp

int main() {
    using my_separator = boost::char_separator<char>;
    using my_tokenizer = boost::tokenizer<my_separator>;
    std::string input{";;Hello|world||-foo--bar;yow;baz|"};
    my_separator sepchars{"-;|"};
    my_tokenizer tokens{input, sepchars};
    for (const auto& t : tokens) {
        std::cout << '<' << t << '>' << ' ';
    }
    std::cout << std::endl;
}

// adapted from Boost.Tokenizer, char_sep_example_1.cpp
#elif PART == 3

int main() {
    using my_separator = boost::char_separator<char>;
    using my_tokenizer = boost::tokenizer<my_separator>;
    std::string input{";;Hello|world||-foo--bar;yow;baz|"};
    my_separator sepchars{"-;", "|", boost::keep_empty_tokens};
    my_tokenizer tokens{input, sepchars};
    for (const auto& t : tokens) {
        std::cout << '<' << t << '>' << ' ';
    }
    std::cout << std::endl;
}

#elif PART == 4
// parse to durations with plus or minus in between
// (alternative approach to regular expressions)

bool parse_duration(const std::string& dur, int& hr, int& mn, int& sc) {
	using boost::tokenizer;
	using boost::char_separator;
	// separate tokens in `dur` at colon
    tokenizer<char_separator<char>> digits{dur, char_separator<char>{":"}};

    auto it = digits.begin();               // start to iterator over sequence ...
    std::size_t pos;                        // (helper to keep track of conversion)
    if (it == digits.end()) return false;   // fail if there are no tokens found
    hr = std::stoi(*it, &pos);              // convert first digit group to hours ...
    if (pos < it->size()) return false;     // ... fail if conversion is incomplete
    if (++it == digits.end()) return false; // fail if there are no more tokens
    mn = std::stoi(*it, &pos);              // convert second digit group to minutes ...
    if (pos < it->size()) return false;     // ... fail if conversion is incomplete
    if (++it == digits.end()) {             // if there are no more tokens ...
    	sc = 0;                             // ... set seconds to 0 ...
    	return true;                        // ... and show success
    }
    sc = std::stoi(*it, &pos);              // convert third digit group to seconds ...
    if (pos < it->size()) return false;     // ... fail if conversion is not complete
    return (++it == digits.end());          // show success (only) if NO FURTHER tokens
}

int main() {
	std::cout.setf(std::ios::boolalpha);

    using my_separator = boost::char_separator<char>;
    using my_tokenizer = boost::tokenizer<my_separator>;
	// separate outer tokens at white-space and '+/-', keeping the latter
    my_separator sepchars{" \t", "-+"};

	std::string line;
	while (std::getline(std::cin, line) && line != "q") {
        my_tokenizer tokens{line, sepchars};
        auto it = tokens.begin();
        if (it == tokens.end()) continue;
        const auto dur1 = *it++;
        if (it == tokens.end()) continue;
        const auto op = *it++;
        if (it == tokens.end()) continue;
        const auto dur2 = *it++;
		std::cout << "dur1=" << dur1
				 << " op=" << op
				 << " dur2=" << dur2
				 << std::endl;
		if (it != tokens.end()) continue;
        if (op != "+" && op != "-") continue;
		int hr1, mn1, sc1;
		if (!parse_duration(dur1, hr1, mn1, sc1)) continue;
		int hr2, mn2, sc2;
		if (!parse_duration(dur2, hr2, mn2, sc2)) continue;
		const auto d1 = 60*(60*hr1 + mn1) + sc1;
		const auto d2 = 60*(60*hr2 + mn2) + sc2;
		const auto total_seconds = (op == "+") ? (d1 + d2) : (d1 - d2);
		std::cout << "total seconds=" << total_seconds << std::endl;
	}
}
#endif

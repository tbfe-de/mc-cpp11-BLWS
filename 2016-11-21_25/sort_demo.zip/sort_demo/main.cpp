/*
 ==============================================================================
 Try `std::vector<const int>` (as suggested by C.A.)
 ==============================================================================
*/

#include <iostream>
#include <vector>

#if 1
template<typename T>
class ConstType {
	const T value;
public:
	ConstType(T v) : value(v) {}
	operator const T &() const { return value; }
};

int main() {
	std::vector<ConstType<int>> vci;
	vci.push_back(42);
//	vci.back() = 22; // <--- should NOT compile
	std::cout << vci.back() << std::endl;
}
#else

int main() {
	std::vector<const int> vci = { 45 };
//	vci.push_back(42);
//	++vci.back(); // <--- should NOT compile
	std::cout << vci.back() << std::endl;
}

#endif

/*
 ==============================================================================
 Try `std::vector<const int>` (as suggested by C.A.)
 ==============================================================================
*/

#include <boost/lambda/lambda.hpp>
#include <algorithm>
#include <vector>
#include <iostream>


bool less(int arg1, int arg2) { return (arg1 < arg2); }

int main() {
	std::vector<int> v = { 45, 12, 13, 20, -1, 8 };
	for (auto e : v) { std::cout << e << ' '; } std::cout << std::endl;
	std::sort(v.begin(), v.end(), less);
	for (auto e : v) { std::cout << e << ' '; } std::cout << std::endl;
}


/*
 ==============================================================================
 Regular Expression Examples
 ==============================================================================
*/

#include <iostream>
#include <string>
#include <regex>

int main() {
	std::cout.setf(std::ios::boolalpha);
	//	std::regex re{R"(-?\d+)"};
	// std::regex re{R"(\d*[.]\d+|\d+[.]\d*)"};
	const std::string hours{R"((\d\d?))"};
	const std::string minutes{R"((\d\d))"};
	const std::string seconds{R"((\d\d))"};
	std::regex re{hours + ':' + minutes + ':' + seconds};
	std::string line;
	while (std::getline(std::cin, line) && line != "q") {
		std::smatch m;
		auto f = std::regex_search(line, m, re);
		std::cout << "f=" << f
				  << " m.position()=" << m.position()
				  << " m.length()=" << m.length()
				  << " m[0]=" << m[0]
 				  << " m[1]=" << m[1]
				  << " m[2]=" << m[2]
				  << " m[3]=" << m[3]
				  << std::endl;
		auto hr = std::stoi(m[1]);
		auto mn = std::stoi(m[2]);
		auto sc = std::stoi(m[3]);
		std::cout << "total seconds=" << 60*(60*hr + mn) + sc << std::endl;

	}
}

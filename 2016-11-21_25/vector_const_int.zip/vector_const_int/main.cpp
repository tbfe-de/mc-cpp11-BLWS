/*
 ==============================================================================
 Try `std::vector<const int>` (as suggested by C.A.)
 ==============================================================================
*/

#include <iostream>
#include <vector>

#if 0
class ConstInt {
	const int value;
public:
	ConstInt(int v) : value(v) {}
	operator const int &() const { return value; }
};

int main() {
	std::vector</*const*/ int> vci;
//	std::vector<ConstInt> vci;
	vci.push_back(42);
//	++vci.back(); // <--- should NOT compile
	std::cout << vci.back() << std::endl;
}
#else

int main() {
	std::vector</*const*/ int> vci;
	vci.push_back(42);
	++vci.back(); // <--- should NOT compile
	std::cout << vci.back() << std::endl;
}

#endif

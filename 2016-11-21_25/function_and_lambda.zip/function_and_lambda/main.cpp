/*
 ==============================================================================
 Demonstrate Various Uses of `std::function` and C+11 Lambdas
 ==============================================================================
 Demonstrate range-based loops defining their loop variables
*/

#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <iterator>
#include <vector>

int x1() { return 0; }
class C1 { public: void operator()() { } };


void the_basics() {
	// see page 3
	std::function<void()> f1;      // no args, returns nothing
	std::function<int(int)> f2;        // int arg, returns int
	                                       // const char* arg,
	std::function<double(const char *)> f3;  // returns double
	                    // const char*, const char**, int arg,
                                             // returns double
	std::function<double(const char *, const char**, int)> f4;

	f1 = x1;
	f1 = C1{};
	f1 = []() { std::cout << "hello, world\n"; };
	f1();
}

template<typename T1, typename T2, typename T3>
T2 filter(T1 beg, T1 end, T2 to, T3 pred) {
    while (beg != end) {
        const auto &val = *beg;
        if (pred(val))
            *to++ = val;
        ++beg;
    }
    return to;
}

void lambda_demo() {
	std::vector<double> data = { 1.2, 3.4, -0.3, 0.1, 7.3 };
	std::vector<double> result;
	filter(data.begin(), data.end(), std::back_inserter(result),
	       [](double e) { return (e < std::sqrt(2.0)); }
	);
#if 0
    for (auto e : result) {
    	std::cout << e << "; ";
    }
#else
    std::for_each(result.begin(), result.end(),
    		[](auto e) { std::cout << e << "; "; }
    );
#endif
    std::cout << std::endl;
}


int main() {
	the_basics();
	lambda_demo();
}

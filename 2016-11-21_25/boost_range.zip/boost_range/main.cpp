#include <cmath>
#include <iostream>
#include <iterator>

#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/range/irange.hpp>

int main() {
	std::ostream_iterator<int> out{std::cout, " "};
	std::vector<int> v = {7, 2, 12};
    int data[] = {3, 7, 17, -9, 8, 7, 0, 5, 5, -1, 0, 3, 2};

    std::cout << "basic use with `std::vector` ................: ";
	boost::sort(v);
	boost::copy(v, out);
	std::cout << std::endl;

	std::cout << "also works with native array ................: ";
	boost::sort(data, [](int a, int b) { return (std::abs(a) < std::abs(b)); });
	boost::copy(data, out);
	std::cout << std::endl;

	std::cout << "reverse with function-style adaptor .........: ";
    boost::copy(boost::adaptors::reverse(data), out);
	std::cout << std::endl;

    std::cout << "reverse with pipeline-style adaptor .........: ";
    boost::copy(data | boost::adaptors::reversed, out);
	std::cout << std::endl;

    std::cout << "remove duplicates with function-style adaptor: ";
    boost::copy(boost::adaptors::unique(data), out);
	std::cout << std::endl;

    std::cout << "remove duplicates with pipeline-style adaptor: ";
    boost::copy(data | boost::adaptors::uniqued, out);
	std::cout << std::endl;

    std::cout << "combine reverse and unique pipeline-style ...: ";
    { using namespace boost::adaptors;
      boost::copy(data | reversed | uniqued, out);
      std::cout << std::endl;
    }

    std::cout << "combine reverse and unique function-style ...: ";
    { namespace ba= boost::adaptors;
      boost::copy(ba::unique(ba::reverse(data)), out);
      std::cout << std::endl;
    }

    std::cout << "simple counting range .......................: ";
    boost::copy(boost::irange(1, 8), out);
    std::cout << std::endl;

    std::cout << "down-Counting range .........................: ";
    boost::copy(boost::irange(6, 2, -1), out);
    std::cout << std::endl;

    std::cout << "More special counting range .................: ";
    boost::copy(boost::irange(3, 32, 9), out);
    std::cout << std::endl;

 }
